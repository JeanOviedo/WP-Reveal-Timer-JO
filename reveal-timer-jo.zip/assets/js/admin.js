/**
 * WP Reveal Timer Admin JS
 */
(function ($) {
    'use strict';

    $(function () {
        // Initialize color pickers
        $('.wprt-color-field').wpColorPicker();
    });

})(jQuery);
